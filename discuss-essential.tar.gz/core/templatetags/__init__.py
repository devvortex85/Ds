# init file for templatetags package
