---
name: Issue
about: "\U0001F6D1 Please use https://codeberg.org/allauth/django-allauth/issues"
title: ''
labels: ''
assignees: ''

---

# 🛑 Stop

The issue tracker has been moved to https://codeberg.org/allauth/django-allauth/issues.
Please submit your issue there.
